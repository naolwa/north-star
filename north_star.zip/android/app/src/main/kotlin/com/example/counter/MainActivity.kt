package com.mycompany.CounterApp

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
