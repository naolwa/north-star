class Business {
  final String id;
  final String name;
  final double employmentRate;
  final double productivity;
  final double revenue;
  final int firmSize;
  final int? cluster;
  final DateTime createdAt;
  final DateTime updatedAt;

  Business({
    required this.id,
    required this.name,
    required this.employmentRate,
    required this.productivity,
    required this.revenue,
    required this.firmSize,
    this.cluster,
    required this.createdAt,
    required this.updatedAt,
  });

  Business copyWith({
    String? id,
    String? name,
    double? employmentRate,
    double? productivity,
    double? revenue,
    int? firmSize,
    int? cluster,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) => Business(
    id: id ?? this.id,
    name: name ?? this.name,
    employmentRate: employmentRate ?? this.employmentRate,
    productivity: productivity ?? this.productivity,
    revenue: revenue ?? this.revenue,
    firmSize: firmSize ?? this.firmSize,
    cluster: cluster ?? this.cluster,
    createdAt: createdAt ?? this.createdAt,
    updatedAt: updatedAt ?? this.updatedAt,
  );

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'employmentRate': employmentRate,
    'productivity': productivity,
    'revenue': revenue,
    'firmSize': firmSize,
    'cluster': cluster,
    'createdAt': createdAt.toIso8601String(),
    'updatedAt': updatedAt.toIso8601String(),
  };

  factory Business.fromJson(Map<String, dynamic> json) => Business(
    id: json['id'] as String,
    name: json['name'] as String,
    employmentRate: (json['employmentRate'] as num).toDouble(),
    productivity: (json['productivity'] as num).toDouble(),
    revenue: (json['revenue'] as num).toDouble(),
    firmSize: json['firmSize'] as int,
    cluster: json['cluster'] as int?,
    createdAt: DateTime.parse(json['createdAt'] as String),
    updatedAt: DateTime.parse(json['updatedAt'] as String),
  );
}
