class ClusterResult {
  final Map<int, Map<String, double>> clusterStats;
  final double silhouetteScore;
  final int totalBusinesses;
  final Map<int, int> clusterCounts;
  final Map<int, String> recommendations;

  ClusterResult({
    required this.clusterStats,
    required this.silhouetteScore,
    required this.totalBusinesses,
    required this.clusterCounts,
    required this.recommendations,
  });

  Map<String, dynamic> toJson() => {
    'clusterStats': clusterStats,
    'silhouetteScore': silhouetteScore,
    'totalBusinesses': totalBusinesses,
    'clusterCounts': clusterCounts,
    'recommendations': recommendations,
  };

  factory ClusterResult.fromJson(Map<String, dynamic> json) => ClusterResult(
    clusterStats: (json['clusterStats'] as Map).map((k, v) => MapEntry(
      int.parse(k.toString()),
      (v as Map).map((k2, v2) => MapEntry(k2.toString(), (v2 as num).toDouble())),
    )),
    silhouetteScore: (json['silhouetteScore'] as num).toDouble(),
    totalBusinesses: json['totalBusinesses'] as int,
    clusterCounts: (json['clusterCounts'] as Map).map((k, v) => MapEntry(int.parse(k.toString()), v as int)),
    recommendations: (json['recommendations'] as Map).map((k, v) => MapEntry(int.parse(k.toString()), v.toString())),
  );
}
