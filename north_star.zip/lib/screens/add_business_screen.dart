import 'package:flutter/material.dart';
import 'package:north_star/models/business.dart';
import 'package:north_star/services/business_service.dart';

class AddBusinessScreen extends StatefulWidget {
  final Business? business;

  const AddBusinessScreen({super.key, this.business});

  @override
  State<AddBusinessScreen> createState() => _AddBusinessScreenState();
}

class _AddBusinessScreenState extends State<AddBusinessScreen> {
  final _formKey = GlobalKey<FormState>();
  final _businessService = BusinessService();
  
  late TextEditingController _nameController;
  late TextEditingController _employmentRateController;
  late TextEditingController _productivityController;
  late TextEditingController _revenueController;
  late TextEditingController _firmSizeController;

  bool _isEditing = false;
  bool _isSaving = false;

  @override
  void initState() {
    super.initState();
    _isEditing = widget.business != null;
    _nameController = TextEditingController(text: widget.business?.name ?? '');
    _employmentRateController = TextEditingController(text: widget.business?.employmentRate.toString() ?? '');
    _productivityController = TextEditingController(text: widget.business?.productivity.toString() ?? '');
    _revenueController = TextEditingController(text: widget.business?.revenue.toString() ?? '');
    _firmSizeController = TextEditingController(text: widget.business?.firmSize.toString() ?? '');
  }

  @override
  void dispose() {
    _nameController.dispose();
    _employmentRateController.dispose();
    _productivityController.dispose();
    _revenueController.dispose();
    _firmSizeController.dispose();
    super.dispose();
  }

  Future<void> _saveBusiness() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isSaving = true);

    final business = Business(
      id: widget.business?.id ?? DateTime.now().millisecondsSinceEpoch.toString(),
      name: _nameController.text.trim(),
      employmentRate: double.parse(_employmentRateController.text),
      productivity: double.parse(_productivityController.text),
      revenue: double.parse(_revenueController.text),
      firmSize: int.parse(_firmSizeController.text),
      cluster: widget.business?.cluster,
      createdAt: widget.business?.createdAt ?? DateTime.now(),
      updatedAt: DateTime.now(),
    );

    if (_isEditing) {
      await _businessService.updateBusiness(business);
    } else {
      await _businessService.addBusiness(business);
    }

    if (mounted) {
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    
    return Scaffold(
      appBar: AppBar(
        title: Text(_isEditing ? 'Edit Business' : 'Add Business'),
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(24),
          children: [
            _buildTextField(
              controller: _nameController,
              label: 'Business Name',
              icon: Icons.business,
              validator: (v) => v?.isEmpty ?? true ? 'Required' : null,
            ),
            const SizedBox(height: 20),
            _buildTextField(
              controller: _employmentRateController,
              label: 'Employment Rate (%)',
              icon: Icons.people,
              keyboardType: TextInputType.number,
              validator: (v) {
                if (v?.isEmpty ?? true) return 'Required';
                final val = double.tryParse(v!);
                if (val == null || val < 0 || val > 100) return 'Enter 0-100';
                return null;
              },
            ),
            const SizedBox(height: 20),
            _buildTextField(
              controller: _productivityController,
              label: 'Productivity Score',
              icon: Icons.speed,
              keyboardType: TextInputType.number,
              validator: (v) {
                if (v?.isEmpty ?? true) return 'Required';
                final val = double.tryParse(v!);
                if (val == null || val < 0) return 'Enter positive number';
                return null;
              },
            ),
            const SizedBox(height: 20),
            _buildTextField(
              controller: _revenueController,
              label: 'Revenue (in thousands)',
              icon: Icons.attach_money,
              keyboardType: TextInputType.number,
              validator: (v) {
                if (v?.isEmpty ?? true) return 'Required';
                final val = double.tryParse(v!);
                if (val == null || val < 0) return 'Enter positive number';
                return null;
              },
            ),
            const SizedBox(height: 20),
            _buildTextField(
              controller: _firmSizeController,
              label: 'Firm Size (employees)',
              icon: Icons.groups,
              keyboardType: TextInputType.number,
              validator: (v) {
                if (v?.isEmpty ?? true) return 'Required';
                final val = int.tryParse(v!);
                if (val == null || val < 1) return 'Enter positive integer';
                return null;
              },
            ),
            const SizedBox(height: 32),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: theme.colorScheme.primary.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.info_outline, color: theme.colorScheme.primary, size: 20),
                      const SizedBox(width: 8),
                      Text('Note', style: theme.textTheme.titleSmall?.copyWith(color: theme.colorScheme.primary, fontWeight: FontWeight.bold)),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'After adding or updating a business, recalculate clusters from the home screen to see updated AI insights.',
                    style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.onSurface.withValues(alpha: 0.7)),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 32),
            ElevatedButton(
              onPressed: _isSaving ? null : _saveBusiness,
              style: ElevatedButton.styleFrom(
                backgroundColor: theme.colorScheme.primary,
                foregroundColor: theme.colorScheme.onPrimary,
                padding: const EdgeInsets.symmetric(vertical: 18),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              child: _isSaving
                  ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                  : Text(_isEditing ? 'Update Business' : 'Add Business', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    TextInputType? keyboardType,
    String? Function(String?)? validator,
  }) {
    final theme = Theme.of(context);
    
    return TextFormField(
      controller: controller,
      keyboardType: keyboardType,
      validator: validator,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon, color: theme.colorScheme.primary),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: theme.colorScheme.primary.withValues(alpha: 0.3)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: theme.colorScheme.primary.withValues(alpha: 0.3)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: theme.colorScheme.primary, width: 2),
        ),
        filled: true,
        fillColor: theme.colorScheme.surface,
      ),
    );
  }
}
