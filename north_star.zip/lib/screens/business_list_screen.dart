import 'package:flutter/material.dart';
import 'package:north_star/models/business.dart';
import 'package:north_star/services/business_service.dart';
import 'package:north_star/widgets/business_card.dart';
import 'package:north_star/screens/add_business_screen.dart';

class BusinessListScreen extends StatefulWidget {
  const BusinessListScreen({super.key});

  @override
  State<BusinessListScreen> createState() => _BusinessListScreenState();
}

class _BusinessListScreenState extends State<BusinessListScreen> {
  final BusinessService _businessService = BusinessService();
  List<Business> _businesses = [];
  List<Business> _filteredBusinesses = [];
  int? _selectedCluster;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    final businesses = await _businessService.getAllBusinesses();
    setState(() {
      _businesses = businesses;
      _filteredBusinesses = businesses;
      _isLoading = false;
    });
  }

  void _filterByCluster(int? cluster) {
    setState(() {
      _selectedCluster = cluster;
      _filteredBusinesses = cluster == null
          ? _businesses
          : _businesses.where((b) => b.cluster == cluster).toList();
    });
  }

  Color _getClusterColor(int? cluster) {
    if (cluster == null) return Colors.grey;
    switch (cluster) {
      case 0: return const Color(0xFF00C853);
      case 1: return const Color(0xFF2196F3);
      case 2: return const Color(0xFFFF6F00);
      default: return Colors.grey;
    }
  }

  Future<void> _deleteBusiness(Business business) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Business'),
        content: Text('Are you sure you want to delete ${business.name}?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Delete', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );

    if (confirm == true) {
      await _businessService.deleteBusiness(business.id);
      _loadData();
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    
    return Scaffold(
      appBar: AppBar(
        title: const Text('All Businesses'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _loadData,
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                _buildFilterChips(theme),
                Expanded(
                  child: _filteredBusinesses.isEmpty
                      ? Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.inbox_outlined, size: 80, color: theme.colorScheme.onSurface.withValues(alpha: 0.3)),
                              const SizedBox(height: 16),
                              Text('No businesses found', style: theme.textTheme.titleMedium?.copyWith(color: theme.colorScheme.onSurface.withValues(alpha: 0.5))),
                            ],
                          ),
                        )
                      : ListView.builder(
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          itemCount: _filteredBusinesses.length,
                          itemBuilder: (_, i) => BusinessCard(
                            business: _filteredBusinesses[i],
                            clusterColor: _getClusterColor(_filteredBusinesses[i].cluster),
                            onTap: () => _showBusinessOptions(_filteredBusinesses[i]),
                          ),
                        ),
                ),
              ],
            ),
    );
  }

  Widget _buildFilterChips(ThemeData theme) => Container(
    padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 20),
    child: SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: [
          _buildChip(theme, 'All', null),
          const SizedBox(width: 8),
          _buildChip(theme, 'Cluster 1', 0),
          const SizedBox(width: 8),
          _buildChip(theme, 'Cluster 2', 1),
          const SizedBox(width: 8),
          _buildChip(theme, 'Cluster 3', 2),
        ],
      ),
    ),
  );

  Widget _buildChip(ThemeData theme, String label, int? cluster) {
    final isSelected = _selectedCluster == cluster;
    final color = cluster == null ? theme.colorScheme.primary : _getClusterColor(cluster);
    
    return FilterChip(
      label: Text(label),
      selected: isSelected,
      onSelected: (_) => _filterByCluster(cluster),
      backgroundColor: theme.colorScheme.surface,
      selectedColor: color.withValues(alpha: 0.2),
      labelStyle: TextStyle(
        color: isSelected ? color : theme.colorScheme.onSurface.withValues(alpha: 0.7),
        fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
      ),
      side: BorderSide(color: color.withValues(alpha: 0.3)),
    );
  }

  void _showBusinessOptions(Business business) {
    showModalBottomSheet(
      context: context,
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.edit),
              title: const Text('Edit'),
              onTap: () async {
                Navigator.pop(context);
                await Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => AddBusinessScreen(business: business)),
                );
                _loadData();
              },
            ),
            ListTile(
              leading: const Icon(Icons.delete, color: Colors.red),
              title: const Text('Delete', style: TextStyle(color: Colors.red)),
              onTap: () {
                Navigator.pop(context);
                _deleteBusiness(business);
              },
            ),
          ],
        ),
      ),
    );
  }
}
