import 'package:flutter/material.dart';
import 'package:north_star/models/business.dart';
import 'package:north_star/models/cluster_result.dart';
import 'package:north_star/services/business_service.dart';
import 'package:north_star/services/clustering_service.dart';
import 'package:north_star/screens/business_list_screen.dart';
import 'package:north_star/screens/insights_screen.dart';
import 'package:north_star/screens/add_business_screen.dart';
import 'package:north_star/widgets/gradient_container.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final BusinessService _businessService = BusinessService();
  final ClusteringService _clusteringService = ClusteringService();
  
  List<Business> _businesses = [];
  ClusterResult? _clusterResult;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    final businesses = await _businessService.getAllBusinesses();
    final result = _clusteringService.analyzeBusinesses(businesses);
    setState(() {
      _businesses = businesses;
      _clusterResult = result;
      _isLoading = false;
    });
  }

  Future<void> _recalculateClusters() async {
    setState(() => _isLoading = true);
    await _businessService.recalculateClusters();
    await _loadData();
  }

  Color _getClusterColor(int cluster) {
    switch (cluster) {
      case 0: return const Color(0xFF00C853);
      case 1: return const Color(0xFF2196F3);
      case 2: return const Color(0xFFFF6F00);
      default: return Colors.grey;
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    
    return Scaffold(
      body: GradientContainer(
        colors: [
          theme.colorScheme.primary.withValues(alpha: 0.1),
          theme.colorScheme.surface,
          theme.colorScheme.secondary.withValues(alpha: 0.05),
        ],
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        child: SafeArea(
          child: _isLoading ? const Center(child: CircularProgressIndicator()) : _buildContent(),
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          await Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const AddBusinessScreen()),
          );
          _loadData();
        },
        icon: const Icon(Icons.add),
        label: const Text('Add Business'),
        backgroundColor: theme.colorScheme.secondary,
      ),
    );
  }

  Widget _buildContent() {
    final theme = Theme.of(context);
    final result = _clusterResult;
    
    return CustomScrollView(
      slivers: [
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(24, 32, 24, 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: theme.colorScheme.primary.withValues(alpha: 0.15),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Icon(Icons.business_center, color: theme.colorScheme.primary, size: 32),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('SDG 8', style: theme.textTheme.titleLarge?.copyWith(color: theme.colorScheme.primary, fontWeight: FontWeight.bold)),
                          Text('Business Insights', style: theme.textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold)),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Text(
                  'Empowering small businesses through AI-driven analytics',
                  style: theme.textTheme.bodyMedium?.copyWith(color: theme.colorScheme.onSurface.withValues(alpha: 0.7)),
                ),
              ],
            ),
          ),
        ),
        if (result != null) ...[
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
              child: Row(
                children: [
                  Expanded(child: _buildStatCard(theme, '${result.totalBusinesses}', 'Total Businesses', Icons.store, theme.colorScheme.primary)),
                  const SizedBox(width: 16),
                  Expanded(child: _buildStatCard(theme, result.silhouetteScore.toStringAsFixed(2), 'Quality Score', Icons.analytics, theme.colorScheme.secondary)),
                ],
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('Cluster Overview', style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
                  TextButton.icon(
                    onPressed: _recalculateClusters,
                    icon: const Icon(Icons.refresh, size: 18),
                    label: const Text('Recalculate'),
                  ),
                ],
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: SizedBox(
              height: 180,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                itemCount: result.clusterCounts.length,
                itemBuilder: (_, i) => _buildClusterPreviewCard(theme, i, result),
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
              child: _buildModelKnowledgeCard(theme, result),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                children: [
                  _buildActionButton(
                    context,
                    theme,
                    'View All Businesses',
                    Icons.list_alt,
                    theme.colorScheme.primary,
                    () => Navigator.push(context, MaterialPageRoute(builder: (_) => const BusinessListScreen())),
                  ),
                  const SizedBox(height: 12),
                  _buildActionButton(
                    context,
                    theme,
                    'Detailed Insights & Charts',
                    Icons.bar_chart,
                    theme.colorScheme.secondary,
                    () => Navigator.push(context, MaterialPageRoute(builder: (_) => InsightsScreen(businesses: _businesses, clusterResult: result))),
                  ),
                ],
              ),
            ),
          ),
        ],
      ],
    );
  }

  Widget _buildStatCard(ThemeData theme, String value, String label, IconData icon, Color color) => Container(
    padding: const EdgeInsets.all(20),
    decoration: BoxDecoration(
      color: theme.colorScheme.surface,
      borderRadius: BorderRadius.circular(20),
      boxShadow: [
        BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 10, offset: const Offset(0, 4)),
      ],
    ),
    child: Column(
      children: [
        Icon(icon, color: color, size: 32),
        const SizedBox(height: 12),
        Text(value, style: theme.textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold, color: color)),
        const SizedBox(height: 4),
        Text(label, style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.onSurface.withValues(alpha: 0.6)), textAlign: TextAlign.center),
      ],
    ),
  );

  Widget _buildClusterPreviewCard(ThemeData theme, int cluster, ClusterResult result) {
    final color = _getClusterColor(cluster);
    final count = result.clusterCounts[cluster] ?? 0;
    final stats = result.clusterStats[cluster];
    
    return Container(
      width: 160,
      margin: const EdgeInsets.all(8),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [color.withValues(alpha: 0.8), color],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(color: color.withValues(alpha: 0.3), blurRadius: 12, offset: const Offset(0, 6)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Cluster ${cluster + 1}', style: theme.textTheme.titleMedium?.copyWith(color: Colors.white, fontWeight: FontWeight.bold)),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.3),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text('$count', style: theme.textTheme.labelMedium?.copyWith(color: Colors.white, fontWeight: FontWeight.bold)),
              ),
            ],
          ),
          if (stats != null) ...[
            const SizedBox(height: 12),
            _buildWhiteStatRow(theme, 'Emp', '${stats['employmentRate']?.toInt()}%'),
            _buildWhiteStatRow(theme, 'Rev', 'R${stats['revenue']?.toInt()}K'),
            _buildWhiteStatRow(theme, 'Size', '${stats['firmSize']?.toInt()}'),
          ],
        ],
      ),
    );
  }

  Widget _buildModelKnowledgeCard(ThemeData theme, ClusterResult result) {
    final descriptor = _describeSilhouetteScore(result.silhouetteScore);
    final totalClusters = result.clusterStats.length;

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
        border: Border.all(
          color: theme.colorScheme.primary.withValues(alpha: 0.2),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Model Knowledge Snapshot',
            style: theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.bold,
              color: theme.colorScheme.primary,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'K-Means grouped ${result.totalBusinesses} businesses into $totalClusters segments using employment rate, productivity, revenue, and firm size.',
            style: theme.textTheme.bodyMedium?.copyWith(
              color: theme.colorScheme.onSurface.withValues(alpha: 0.75),
            ),
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: theme.colorScheme.primary.withValues(alpha: 0.08),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(Icons.insights, color: theme.colorScheme.primary, size: 20),
                const SizedBox(width: 12),
                Expanded(
                  child: RichText(
                    text: TextSpan(
                      style: theme.textTheme.bodyMedium?.copyWith(
                        color: theme.colorScheme.onSurface.withValues(alpha: 0.8),
                      ),
                      children: [
                        TextSpan(
                          text: 'Silhouette score ${result.silhouetteScore.toStringAsFixed(2)} ',
                        ),
                        TextSpan(
                          text: descriptor,
                          style: theme.textTheme.bodyMedium?.copyWith(
                            color: theme.colorScheme.primary,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Text(
            'How to use these insights:',
            style: theme.textTheme.titleSmall?.copyWith(
              fontWeight: FontWeight.w600,
              color: theme.colorScheme.onSurface,
            ),
          ),
          const SizedBox(height: 8),
          ...result.clusterStats.entries.map((entry) {
            final cluster = entry.key;
            final stats = entry.value;
            final employment = stats['employmentRate']?.toStringAsFixed(0) ?? '-';
            final revenue = stats['revenue']?.toStringAsFixed(0) ?? '-';
            final recommendation = result.recommendations[cluster] ?? '';

            return Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(Icons.lightbulb, color: _getClusterColor(cluster), size: 20),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      'Cluster ${cluster + 1} · Employment ~ ${employment}% · Revenue ~ R${revenue}K\n$recommendation',
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: theme.colorScheme.onSurface.withValues(alpha: 0.8),
                        height: 1.3,
                      ),
                    ),
                  ),
                ],
              ),
            );
          }),
          const SizedBox(height: 4),
          Text(
            'Share these findings with local partners to coordinate support that advances decent work and inclusive growth.',
            style: theme.textTheme.bodySmall?.copyWith(
              color: theme.colorScheme.onSurface.withValues(alpha: 0.7),
            ),
          ),
        ],
      ),
    );
  }

  String _describeSilhouetteScore(double score) {
    if (score >= 0.6) {
      return 'indicates well-separated clusters—use it to highlight proven success patterns.';
    } else if (score >= 0.3) {
      return 'suggests moderately distinct groups—target interventions while continuing to gather data.';
    } else {
      return 'shows overlapping clusters—consider adding more business data to sharpen segmentation.';
    }
  }

  Widget _buildWhiteStatRow(ThemeData theme, String label, String value) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 2),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: theme.textTheme.bodySmall?.copyWith(color: Colors.white.withValues(alpha: 0.9))),
        Text(value, style: theme.textTheme.bodySmall?.copyWith(color: Colors.white, fontWeight: FontWeight.bold)),
      ],
    ),
  );

  Widget _buildActionButton(BuildContext context, ThemeData theme, String label, IconData icon, Color color, VoidCallback onTap) => InkWell(
    onTap: onTap,
    borderRadius: BorderRadius.circular(16),
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 18),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withValues(alpha: 0.3), width: 1.5),
      ),
      child: Row(
        children: [
          Icon(icon, color: color, size: 24),
          const SizedBox(width: 16),
          Expanded(child: Text(label, style: theme.textTheme.titleMedium?.copyWith(color: color, fontWeight: FontWeight.w600))),
          Icon(Icons.arrow_forward_ios, color: color, size: 16),
        ],
      ),
    ),
  );
}
