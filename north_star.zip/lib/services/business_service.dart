import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:north_star/models/business.dart';
import 'package:north_star/services/clustering_service.dart';

class BusinessService {
  static const String _storageKey = 'businesses';
  final ClusteringService _clusteringService = ClusteringService();

  Future<List<Business>> getAllBusinesses() async {
    final prefs = await SharedPreferences.getInstance();
    final jsonString = prefs.getString(_storageKey);

    if (jsonString == null || jsonString.isEmpty) {
      final sampleData = _generateSampleData();
      await _saveBusinesses(sampleData);
      return sampleData;
    }

    final List<dynamic> jsonList = json.decode(jsonString);
    return jsonList.map((json) => Business.fromJson(json)).toList();
  }

  Future<void> addBusiness(Business business) async {
    final businesses = await getAllBusinesses();
    businesses.add(business);
    await _saveBusinesses(businesses);
  }

  Future<void> updateBusiness(Business business) async {
    final businesses = await getAllBusinesses();
    final index = businesses.indexWhere((b) => b.id == business.id);
    if (index != -1) {
      businesses[index] = business;
      await _saveBusinesses(businesses);
    }
  }

  Future<void> deleteBusiness(String id) async {
    final businesses = await getAllBusinesses();
    businesses.removeWhere((b) => b.id == id);
    await _saveBusinesses(businesses);
  }

  Future<List<Business>> recalculateClusters() async {
    final businesses = await getAllBusinesses();
    
    if (businesses.isEmpty) return businesses;

    final assignments = _clusteringService.performClustering(businesses);
    
    final updatedBusinesses = <Business>[];
    for (int i = 0; i < businesses.length; i++) {
      updatedBusinesses.add(businesses[i].copyWith(
        cluster: assignments[i],
        updatedAt: DateTime.now(),
      ));
    }

    await _saveBusinesses(updatedBusinesses);
    return updatedBusinesses;
  }

  Future<void> _saveBusinesses(List<Business> businesses) async {
    final prefs = await SharedPreferences.getInstance();
    final jsonString = json.encode(businesses.map((b) => b.toJson()).toList());
    await prefs.setString(_storageKey, jsonString);
  }

  List<Business> _generateSampleData() {
    final now = DateTime.now();
    return [
      Business(
        id: '1',
        name: 'TechStart Solutions',
        employmentRate: 85.0,
        productivity: 9.2,
        revenue: 250.0,
        firmSize: 45,
        cluster: 0,
        createdAt: now.subtract(const Duration(days: 120)),
        updatedAt: now,
      ),
      Business(
        id: '2',
        name: 'Green Earth Organics',
        employmentRate: 72.0,
        productivity: 7.8,
        revenue: 180.0,
        firmSize: 28,
        cluster: 1,
        createdAt: now.subtract(const Duration(days: 90)),
        updatedAt: now,
      ),
      Business(
        id: '3',
        name: 'Local Craft Hub',
        employmentRate: 45.0,
        productivity: 5.2,
        revenue: 65.0,
        firmSize: 12,
        cluster: 2,
        createdAt: now.subtract(const Duration(days: 60)),
        updatedAt: now,
      ),
      Business(
        id: '4',
        name: 'Urban Design Studio',
        employmentRate: 88.0,
        productivity: 9.5,
        revenue: 320.0,
        firmSize: 52,
        cluster: 0,
        createdAt: now.subtract(const Duration(days: 150)),
        updatedAt: now,
      ),
      Business(
        id: '5',
        name: 'FreshBite Catering',
        employmentRate: 68.0,
        productivity: 7.3,
        revenue: 145.0,
        firmSize: 22,
        cluster: 1,
        createdAt: now.subtract(const Duration(days: 75)),
        updatedAt: now,
      ),
      Business(
        id: '6',
        name: 'HandMade Textiles',
        employmentRate: 38.0,
        productivity: 4.8,
        revenue: 52.0,
        firmSize: 8,
        cluster: 2,
        createdAt: now.subtract(const Duration(days: 45)),
        updatedAt: now,
      ),
      Business(
        id: '7',
        name: 'Innovation Labs',
        employmentRate: 92.0,
        productivity: 10.2,
        revenue: 420.0,
        firmSize: 68,
        cluster: 0,
        createdAt: now.subtract(const Duration(days: 180)),
        updatedAt: now,
      ),
      Business(
        id: '8',
        name: 'Community Bakery',
        employmentRate: 75.0,
        productivity: 8.1,
        revenue: 165.0,
        firmSize: 25,
        cluster: 1,
        createdAt: now.subtract(const Duration(days: 100)),
        updatedAt: now,
      ),
      Business(
        id: '9',
        name: 'StartUp Ventures',
        employmentRate: 42.0,
        productivity: 5.5,
        revenue: 78.0,
        firmSize: 15,
        cluster: 2,
        createdAt: now.subtract(const Duration(days: 30)),
        updatedAt: now,
      ),
      Business(
        id: '10',
        name: 'Digital Marketing Pro',
        employmentRate: 80.0,
        productivity: 8.8,
        revenue: 290.0,
        firmSize: 38,
        cluster: 0,
        createdAt: now.subtract(const Duration(days: 110)),
        updatedAt: now,
      ),
      Business(
        id: '11',
        name: 'EcoFriendly Goods',
        employmentRate: 70.0,
        productivity: 7.5,
        revenue: 155.0,
        firmSize: 20,
        cluster: 1,
        createdAt: now.subtract(const Duration(days: 85)),
        updatedAt: now,
      ),
      Business(
        id: '12',
        name: 'Village Crafts Co.',
        employmentRate: 35.0,
        productivity: 4.2,
        revenue: 48.0,
        firmSize: 6,
        cluster: 2,
        createdAt: now.subtract(const Duration(days: 25)),
        updatedAt: now,
      ),
    ];
  }
}
