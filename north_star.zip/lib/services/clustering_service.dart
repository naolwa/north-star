import 'dart:math';
import 'package:north_star/models/business.dart';
import 'package:north_star/models/cluster_result.dart';

class ClusteringService {
  static const int numClusters = 3;
  static const int maxIterations = 100;

  List<List<double>> _normalizeData(List<Business> businesses) {
    if (businesses.isEmpty) return [];

    final features = businesses.map((b) => [
      b.employmentRate,
      b.productivity,
      b.revenue,
      b.firmSize.toDouble(),
    ]).toList();

    final means = List.generate(4, (i) => 
      features.map((f) => f[i]).reduce((a, b) => a + b) / features.length
    );

    final stdDevs = List.generate(4, (i) {
      final mean = means[i];
      final variance = features.map((f) => pow(f[i] - mean, 2)).reduce((a, b) => a + b) / features.length;
      return sqrt(variance);
    });

    return features.map((f) => 
      List.generate(4, (i) => stdDevs[i] > 0 ? (f[i] - means[i]) / stdDevs[i] : 0.0)
    ).toList();
  }

  double _euclideanDistance(List<double> a, List<double> b) {
    double sum = 0;
    for (int i = 0; i < a.length; i++) {
      sum += pow(a[i] - b[i], 2);
    }
    return sqrt(sum);
  }

  List<int> performClustering(List<Business> businesses) {
    if (businesses.length < numClusters) {
      return List.generate(businesses.length, (i) => 0);
    }

    final normalizedData = _normalizeData(businesses);
    final random = Random(42);
    
    List<List<double>> centroids = List.generate(
      numClusters,
      (i) => normalizedData[random.nextInt(normalizedData.length)].toList(),
    );

    List<int> assignments = List.filled(businesses.length, 0);

    for (int iter = 0; iter < maxIterations; iter++) {
      bool changed = false;

      for (int i = 0; i < normalizedData.length; i++) {
        double minDist = double.infinity;
        int bestCluster = 0;

        for (int c = 0; c < numClusters; c++) {
          final dist = _euclideanDistance(normalizedData[i], centroids[c]);
          if (dist < minDist) {
            minDist = dist;
            bestCluster = c;
          }
        }

        if (assignments[i] != bestCluster) {
          assignments[i] = bestCluster;
          changed = true;
        }
      }

      if (!changed) break;

      for (int c = 0; c < numClusters; c++) {
        final clusterPoints = <List<double>>[];
        for (int i = 0; i < normalizedData.length; i++) {
          if (assignments[i] == c) {
            clusterPoints.add(normalizedData[i]);
          }
        }

        if (clusterPoints.isNotEmpty) {
          centroids[c] = List.generate(4, (dim) =>
            clusterPoints.map((p) => p[dim]).reduce((a, b) => a + b) / clusterPoints.length
          );
        }
      }
    }

    return assignments;
  }

  double calculateSilhouetteScore(List<Business> businesses, List<int> assignments) {
    if (businesses.length < 2) return 0.0;

    final normalizedData = _normalizeData(businesses);
    double totalScore = 0;

    for (int i = 0; i < businesses.length; i++) {
      final myCluster = assignments[i];
      
      final sameClusterIndices = <int>[];
      for (int j = 0; j < assignments.length; j++) {
        if (i != j && assignments[j] == myCluster) {
          sameClusterIndices.add(j);
        }
      }

      if (sameClusterIndices.isEmpty) continue;

      final a = sameClusterIndices
        .map((j) => _euclideanDistance(normalizedData[i], normalizedData[j]))
        .reduce((x, y) => x + y) / sameClusterIndices.length;

      double minB = double.infinity;
      for (int c = 0; c < numClusters; c++) {
        if (c == myCluster) continue;

        final otherClusterIndices = <int>[];
        for (int j = 0; j < assignments.length; j++) {
          if (assignments[j] == c) {
            otherClusterIndices.add(j);
          }
        }

        if (otherClusterIndices.isNotEmpty) {
          final b = otherClusterIndices
            .map((j) => _euclideanDistance(normalizedData[i], normalizedData[j]))
            .reduce((x, y) => x + y) / otherClusterIndices.length;
          minB = min(minB, b);
        }
      }

      if (minB != double.infinity) {
        totalScore += (minB - a) / max(a, minB);
      }
    }

    return businesses.length > 0 ? totalScore / businesses.length : 0.0;
  }

  ClusterResult analyzeBusinesses(List<Business> businesses) {
    if (businesses.isEmpty) {
      return ClusterResult(
        clusterStats: {},
        silhouetteScore: 0.0,
        totalBusinesses: 0,
        clusterCounts: {},
        recommendations: {},
      );
    }

    final assignments = performClustering(businesses);
    final silhouetteScore = calculateSilhouetteScore(businesses, assignments);

    final clusterStats = <int, Map<String, double>>{};
    final clusterCounts = <int, int>{};

    for (int c = 0; c < numClusters; c++) {
      final clusterBusinesses = <Business>[];
      for (int i = 0; i < businesses.length; i++) {
        if (assignments[i] == c) {
          clusterBusinesses.add(businesses[i]);
        }
      }

      if (clusterBusinesses.isNotEmpty) {
        clusterCounts[c] = clusterBusinesses.length;
        clusterStats[c] = {
          'employmentRate': clusterBusinesses.map((b) => b.employmentRate).reduce((a, b) => a + b) / clusterBusinesses.length,
          'productivity': clusterBusinesses.map((b) => b.productivity).reduce((a, b) => a + b) / clusterBusinesses.length,
          'revenue': clusterBusinesses.map((b) => b.revenue).reduce((a, b) => a + b) / clusterBusinesses.length,
          'firmSize': clusterBusinesses.map((b) => b.firmSize).reduce((a, b) => a + b) / clusterBusinesses.length,
        };
      }
    }

    final recommendations = _generateRecommendations(clusterStats);

    return ClusterResult(
      clusterStats: clusterStats,
      silhouetteScore: silhouetteScore,
      totalBusinesses: businesses.length,
      clusterCounts: clusterCounts,
      recommendations: recommendations,
    );
  }

  Map<int, String> _generateRecommendations(Map<int, Map<String, double>> clusterStats) {
    final recommendations = <int, String>{};

    clusterStats.forEach((cluster, stats) {
      final employment = stats['employmentRate'] ?? 0;
      final productivity = stats['productivity'] ?? 0;
      final revenue = stats['revenue'] ?? 0;

      if (employment > 75 && productivity > 8 && revenue > 150) {
        recommendations[cluster] = 'High-performing businesses. Focus on scaling operations and market expansion to create more decent jobs.';
      } else if (employment > 60 && revenue > 100) {
        recommendations[cluster] = 'Stable businesses with growth potential. Invest in productivity improvements and workforce training.';
      } else {
        recommendations[cluster] = 'Emerging businesses requiring support. Provide access to financing, mentorship, and capacity building to accelerate growth.';
      }
    });

    return recommendations;
  }
}
